function arrayMin(number1, number2) {
    return number1 < number2 ? number1 : number2;
}

console.log('Min number is: ' + arrayMin(23, 14));